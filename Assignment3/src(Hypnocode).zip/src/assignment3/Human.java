package assignment3;
/**
*
* @author Hypnocode
*/
public class Human extends Player
{
    public void setThrow(Throw aThrow)
    {
        myThrow = aThrow;
    }
}


