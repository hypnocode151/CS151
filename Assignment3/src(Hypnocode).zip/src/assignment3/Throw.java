package assignment3;

/**
*
* @author Hypnocode
*/
public enum Throw
{
    ROCK,PAPER,SCISSORS, NULL
}