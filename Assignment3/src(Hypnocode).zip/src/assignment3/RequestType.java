package assignment3;

/**
*
* @author Hypnocode
*/
public enum RequestType
{
    TEXTREQUEST
}

