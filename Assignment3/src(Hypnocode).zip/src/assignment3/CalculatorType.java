package assignment3;

/**
 *
 * @author Zane Melcho
 */
public enum CalculatorType 
{
    RANDOM
}
