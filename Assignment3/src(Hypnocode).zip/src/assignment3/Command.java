package assignment3;

/**
*
* @author Hypnocode
*/
public enum Command
{
    THROWROCK,THROWPAPER,THROWSCISSORS,HELP,SCORE,QUIT
    
}