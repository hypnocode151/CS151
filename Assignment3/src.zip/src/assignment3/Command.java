package assignment3;

/**
*the Command class is an enum class with all the commands of the game
* @author Hypnocode
* 
*/
public enum Command
{
    THROWROCK,THROWPAPER,THROWSCISSORS,HELP,SCORE,QUIT
    
}