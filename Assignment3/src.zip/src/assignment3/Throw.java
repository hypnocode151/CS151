package assignment3;

/**
*
* @author Hypnocode
* The Throw class contains the enum types of the throws.
*/
public enum Throw
{
    ROCK,PAPER,SCISSORS, NULL
}