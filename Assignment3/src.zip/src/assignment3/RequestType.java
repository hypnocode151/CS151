package assignment3;

/**
*
* @author Hypnocode
* The RequestType class contains the enum type TEXTREQUEST.
*/
public enum RequestType
{
    TEXTREQUEST
}

